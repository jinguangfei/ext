from .config import settings as settings

TORTOISE_ORM = settings.TORTOISE_ORM
